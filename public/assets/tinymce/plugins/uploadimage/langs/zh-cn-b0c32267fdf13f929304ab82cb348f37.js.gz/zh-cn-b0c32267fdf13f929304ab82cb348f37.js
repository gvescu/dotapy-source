tinyMCE.addI18n('zh-cn', {
  'Insert an image from your computer': "\u4e0a\u4f20\u56fe\u7247",
  'Insert image': "\u63d2\u5165\u56fe\u7247",
  'Choose an image': "\u9009\u62e9\u56fe\u7247",
  'You must choose a file': "\u5fc5\u987b\u9009\u62e9\u6587\u4ef6",
  'Got a bad response from the server': "\u670d\u52a1\u5668\u8fd4\u56de\u9519\u8bef",
  "Didn't get a response from the server": "\u670d\u52a1\u5668\u6ca1\u6709\u54cd\u5e94",
  'Insert': "\u63d2\u5165",
  'Cancel': "\u53d6\u6d88",
  'Image description': "\u56fe\u7247\u63cf\u8ff0",
});
